/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tau.ang.exercise.pkg3;

public class Song{
    String name;
    String album;
    String length;
    String artist;
    String genre;
    int timesPlayed;
    
    public void playSong (){
        timesPlayed++;
    }
}

public class Singer{
    String name;
    int noOfPerformances;
    double earnings;
    Song favoriteSong;
    int audienceMember;
    
    public void performForAudience(){
        noOfPerformances++;
        earnings += 100*audienceMember;
    }
    
    public void changeFavSong (){
        favoriteSong = 
    }
}

public class TauAngExercise3 {

    public static void main(String[] args) {
        
    }
    
}
